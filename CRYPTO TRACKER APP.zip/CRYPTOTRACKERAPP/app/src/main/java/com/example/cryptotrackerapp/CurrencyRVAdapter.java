package com.example.cryptotrackerapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.text.DecimalFormat;
import java.util.ArrayList;

public class CurrencyRVAdapter extends RecyclerView.Adapter<CurrencyRVAdapter.CurrencyViewHolder> {
    private ArrayList<CurrencyModal> currencyModals;
    private ArrayList<CurrencyModal> currencyModalArrayList = new ArrayList<>();

    private Context context;
    private static DecimalFormat df2 = new DecimalFormat("#.##");

    public CurrencyRVAdapter(ArrayList<CurrencyModal> currencyModals, Context context) {
        this.currencyModals = currencyModals;
        this.context = context;
    }

    public void filterList(ArrayList<CurrencyModal> filterList) {
        this.currencyModals = filterList;
        notifyDataSetChanged();
    }


    @NonNull
    @Override
    public CurrencyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.currency_rv_item, parent, false);
        return new CurrencyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CurrencyViewHolder holder, int position) {
        CurrencyModal modal = currencyModals.get(position);
        holder.nameTV.setText(modal.getName());
        holder.rateTV.setText("$ " + df2.format(modal.getPrice()));
        holder.symbolTV.setText(modal.getSymbol());
    }

    @Override
    public int getItemCount() {
        return currencyModals.size();
    }

    public ArrayList<CurrencyModal> getCurrencyModalArrayList() {
        return currencyModalArrayList;
    }

    public void setCurrencyModalArrayList(ArrayList<CurrencyModal> currencyModalArrayList) {
        this.currencyModalArrayList = currencyModalArrayList;
    }

    public static class CurrencyViewHolder extends RecyclerView.ViewHolder {
        private TextView symbolTV, rateTV, nameTV;

        public CurrencyViewHolder(@NonNull View itemView) {
            super(itemView);
            symbolTV = itemView.findViewById(R.id.idTVSymbol);
            rateTV = itemView.findViewById(R.id.idTVRate);
            nameTV = itemView.findViewById(R.id.idTVName);
        }
    }
}