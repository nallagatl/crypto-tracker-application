package com.example.cryptotrackerapp;

import android.os.Bundle;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;

import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;


import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;

import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private RecyclerView currencyRV;
    private EditText searchEdt;
    private ArrayList<CurrencyModal> currencyModalArrayList;
    private CurrencyRVAdapter currencyRVAdapter;
    private ProgressBar loadingPB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initializing UI elements
        searchEdt = findViewById(R.id.idEdtCurrency);
        loadingPB = findViewById(R.id.idPBLoading);
        currencyRV = findViewById(R.id.idRVcurrency);

        // Initializing the currency list and adapter
        currencyModalArrayList = new ArrayList<>();
        currencyRVAdapter = new CurrencyRVAdapter(currencyModalArrayList, this);
        currencyRV.setLayoutManager(new LinearLayoutManager(this));
        currencyRV.setAdapter(currencyRVAdapter);

        // Fetch currency data
        getData();

        // Adding a TextWatcher to filter results dynamically
        searchEdt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                filter(s.toString());
            }
        });
    }

    // Method to filter the list
    private void filter(String filter) {
        ArrayList<CurrencyModal> filteredList = new ArrayList<>();
        for (CurrencyModal item : currencyModalArrayList) {
            if (item.getName().toLowerCase().contains(filter.toLowerCase())) {
                filteredList.add(item);
            }
        }
        currencyRVAdapter.filterList(filteredList);
    }

    // Method to fetch cryptocurrency data
    private void getData() {
        // API URL
        String url = "https://pro-api.coinmarketcap.com/v1/cryptocurrency/listings/latest";

        // Create a new request queue
        RequestQueue queue = Volley.newRequestQueue(this);

        // JSON Request using lambda expressions
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null,
                response -> {
                    // Hide progress bar when data is loaded
                    loadingPB.setVisibility(View.GONE);
                    try {
                        // Extract JSON array "data"
                        JSONArray dataArray = response.getJSONArray("data");
                        for (int i = 0; i < dataArray.length(); i++) {
                            JSONObject dataObj = dataArray.getJSONObject(i);
                            String symbol = dataObj.getString("symbol");
                            String name = dataObj.getString("name");
                            double price = dataObj.getJSONObject("quote").getJSONObject("USD").getDouble("price");

                            // Add extracted data to the list
                            currencyModalArrayList.add(new CurrencyModal(name, symbol, price));
                        }
                        // Notify adapter of data changes
                        currencyRVAdapter.notifyDataSetChanged();
                    } catch (JSONException e) {
                        Log.e("JSONError", "Error parsing JSON data", e);
                        Toast.makeText(MainActivity.this, "Error parsing data", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> {
                    Log.e("APIError", "Error fetching data from API", error);
                    Toast.makeText(MainActivity.this, "Error fetching data", Toast.LENGTH_SHORT).show();
                }
        ) {
            @Override
            public Map<String, String> getHeaders() {
                // Add API key in the headers
                HashMap<String, String> headers = new HashMap<>();
                headers.put("X-CMC_PRO_API_KEY", "11a07dcb-7903-4af8-b527-c2a078175101"); // 🔴 Replace with your actual API key
                return headers;
            }
        };

        // Add request to queue
        queue.add(jsonObjectRequest);
    }

}